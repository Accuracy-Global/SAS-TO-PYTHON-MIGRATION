import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-datastep-statements',
  templateUrl: './datastep-statements.component.html',
  styleUrls: ['./datastep-statements.component.css']
})
export class DatastepStatementsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
