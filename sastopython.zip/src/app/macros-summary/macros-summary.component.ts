import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-macros-summary',
  templateUrl: './macros-summary.component.html',
  styleUrls: ['./macros-summary.component.css']
})
export class MacrosSummaryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
