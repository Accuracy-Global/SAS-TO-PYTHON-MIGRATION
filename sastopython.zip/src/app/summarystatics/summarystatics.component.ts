import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-summarystatics',
  templateUrl: './summarystatics.component.html',
  styleUrls: ['./summarystatics.component.css']
})
export class SummarystaticsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
