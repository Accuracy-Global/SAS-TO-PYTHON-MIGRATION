export const environment = {
  production: true,
  api : 'http://208.51.61.118:5000/' 
};
